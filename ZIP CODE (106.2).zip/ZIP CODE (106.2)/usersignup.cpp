


#include "usersignup.h"
#include "ui_usersignup.h"

#include "userlogin.h"  //adding the header file userlogin
#include <QMessageBox>   // adding to diplay the message on ui

#include <QtSql>
#include <QSqlDatabase>


UserSignup::UserSignup(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UserSignup)
{
    ui->setupUi(this);

}

UserSignup::~UserSignup()
{
    delete ui;
}

void UserSignup::on_pushButton_Login_clicked()
{
    this->hide();   // will hide the usersignup ui
    UserLogin ul;    // callling an object of the userlogin class
    ul.setModal(true);  // setting modal is true then
    ul.exec();     // will show the userlogin ui
}




void UserSignup::on_registerbtn_clicked()
{
    //connecting to SQLITE database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");

   database.setDatabaseName("C:/Users/Nirmala/user_register.db");       // Path to my database

   if(database.open())
   {
       //Retrieve Data from Input Fields

       QString username = ui->username->text();
       QString dateofbirth = ui->dateofbirth->text();
       QString emailaddress = ui->emailaddress->text();
       QString password = ui->password->text();
       QString mobile = ui->mobile->text();
       QString confirmpassword = ui->confirmpassword->text();

       //run our insert query

      QSqlQuery qry;
     qry.prepare("INSERT INTO users_details (username, dateofbirth, mobile, emailaddress, password, confirmpassword) values('"+username+"','"+dateofbirth+"','"+mobile+"','"+emailaddress+"','"+password+"','"+confirmpassword+"')");





    //want to execute and see
    if(qry.exec()){
       QMessageBox::information(this,"Inserted","Data inserted successfully");
   }
    else{
         QMessageBox::information(this,"Not Inserted","Data is not inserted");
   }
   }
   else
   {
       QMessageBox::information(this, "Not Connected", "Database is not connected");
   }
}

