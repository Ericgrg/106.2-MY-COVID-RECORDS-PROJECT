#include "userlogin.h"
#include "ui_userlogin.h"


#include "dashboard.h"      // adding header file of dashboard so that we can use the class  in it
#include "usersignup.h"    // adding header file of usersignup so that we can call the class in it
#include <QMessageBox>     // adding to show the message on ui.


UserLogin::UserLogin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::UserLogin)
{
    ui->setupUi(this);

}

UserLogin::~UserLogin()
{
    delete ui;
}

void UserLogin::on_pushButton_SignUp_clicked()
{
    this->hide();        // will hide the userlogin ui
    UserSignup us;       //creating an object of usersignup class
    us.setModal(true);    // setting modal is true
    us.exec();            // will open the new dailog signp ui
}


void UserLogin::on_pushButton_clicked()
{

    //connecting to SQLITE database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");

   database.setDatabaseName("C:/Users/Nirmala/user_register.db");       // Path to my database

  if(database.open())
   {
       //Retrieve Data from Input Fields

    QString emailaddress, password;
    emailaddress=ui->lineEdit_email->text();
    password=ui->lineEdit_password->text();

       //run our insert query

      QSqlQuery qry;
     qry.prepare("select * from users_details where emailaddress='"+emailaddress+"' and password='"+password+"' ");





    //want to execute and see
    if(qry.exec())
     {
        int count=0;
        while(qry.next())
        {
          count++;
        }
        if(count==1)
        {
          //  ui->label_6->setText("emailaddress and password is correct");
             QMessageBox::information(this, tr("login "), tr("successfully login"));
             this->hide();     // will hide the userlogin ui
                 Dashboard dashBoard; // creating a object of dashboard class
                dashBoard.setModal(true); // setting modal is true
                dashBoard.exec();// will open the new dailog of dashboard ui

           }
           if(count>1)
               QMessageBox::information(this, tr("login "), tr("Duplicate emailaddress and password "));

                       if(count<1)
                           QMessageBox::information(this, tr("login "), tr("Emailaddress and password is not correct"));

     }

   }

}

