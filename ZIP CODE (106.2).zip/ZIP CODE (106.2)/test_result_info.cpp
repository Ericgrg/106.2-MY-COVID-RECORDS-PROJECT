#include "test_result_info.h"
#include "ui_test_result_info.h"

#include "dashboard.h"      // adding header file of dashboard so that we can use the class  in it

#include <QMessageBox>   // adding to diplay the message on ui


test_result_info::test_result_info(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::test_result_info)
{
    ui->setupUi(this);
}

test_result_info::~test_result_info()
{
    delete ui;
}

void test_result_info::on_save_clicked()
{
    //connecting to SQLITE database



   QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
   db.setDatabaseName("C:/Users/Nirmala/user_register.db"); // Path to my database


   if(db.open())
   {
       //Retrieve Data from Input Fields
       QString test_date = ui->test_date->text();
       QString test_type = ui->test_type->text();
       QString test_result = ui->test_result->text();


       //run our insert query

      QSqlQuery qry;
     qry.prepare("INSERT INTO test_info(testdate, testtype, testresult) values('"+test_date+"','"+test_type+"','"+test_result+"')");





    //want to execute and see
    if(qry.exec()){
       QMessageBox::information(this,"Inserted","Data inserted successfully");
   }
    else{
         QMessageBox::information(this,"Not Inserted","Data is not inserted");
   }

 }



}


void test_result_info::on_back_clicked()
{
    this->hide();        // will hide the test_result_info ui
    Dashboard db;       //creating an object of dashboard class
    db.setModal(true);    // setting modal is true
    db.exec();            // will open the new dashboard ui
}

