#include "bookappointment.h"
#include "ui_bookappointment.h"

#include "dashboard.h"    // including the header file dashboard in it
#include <QMessageBox>     // adding to show the message on ui.

bookappointment::bookappointment(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::bookappointment)
{
    ui->setupUi(this);
}

bookappointment::~bookappointment()
{
    delete ui;
}

void bookappointment::on_backbutton_clicked()
{
    this->hide();          // will hide the bookappointment ui
    Dashboard dashBoard;   // calling the object of dashboard class
   dashBoard.setModal(true); // setting modal is true then
    dashBoard.exec();       // will show the dashboard ui
}





void bookappointment::on_confirmbutton_clicked()
{
    //once fillup the date and time it will show the message
QMessageBox::information(this, tr("Appointment time "), tr("successfully booked the appointment date and time"));
}
