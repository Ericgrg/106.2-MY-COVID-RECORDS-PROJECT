#ifndef RATTEST_H
#define RATTEST_H

#include <QDialog>

namespace Ui {
class rattest;
}

class rattest : public QDialog
{
    Q_OBJECT

public:
    explicit rattest(QWidget *parent = nullptr);
    ~rattest();

private slots:
    void on_backbutton_clicked();

    void on_savebutton_clicked();

private:
    Ui::rattest *ui;
};

#endif // RATTEST_H
