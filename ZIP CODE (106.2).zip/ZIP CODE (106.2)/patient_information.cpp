#include "patient_information.h"
#include "ui_patient_information.h"


#include "dashboard.h"      // adding header file of dashboard so that we can use the class  in it

#include <QMessageBox>   // adding to diplay the message on ui

#include <QtSql>
#include <QSqlDatabase>

patient_information::patient_information(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::patient_information)
{
    ui->setupUi(this);
}

patient_information::~patient_information()
{
    delete ui;
}

void patient_information::on_pushButtonsave_clicked()
{

    //connecting to SQLITE database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");

   database.setDatabaseName("C:/Users/Nirmala/user_register.db");       // Path to my database

   if(database.open())
   {
       //Retrieve Data from Input Fields
       QString name = ui->name->text();
       QString date = ui->date->text();
       QString cellnumber = ui->cellnumber->text();
       QString address = ui->address->text();
       QString vaccinestatus = ui->vaccinestatus->text();

       //run our insert query

      QSqlQuery qry;
     qry.prepare("INSERT INTO patient_info (patientname, vaccinedate, cellnumber, address, vaccinestatus) values('"+name+"','"+date+"','"+cellnumber+"','"+address+"','"+vaccinestatus+"')");





    //want to execute and see
    if(qry.exec()){
       QMessageBox::information(this,"Inserted","Data inserted successfully");
   }
    else{
         QMessageBox::information(this,"Not Inserted","Data is not inserted");
   }

 }

}


void patient_information::on_pushButtongoback_clicked()
{
    this->hide();        // will hide the patient_information ui
    Dashboard db;       //creating an object of dashboard class
    db.setModal(true);    // setting modal is true
    db.exec();            // will open the new dashboard ui

}

