#ifndef PATIENT_INFORMATION_H
#define PATIENT_INFORMATION_H

#include <QDialog>
#include <QtSql>
#include <QSqlDatabase>
#include <QMessageBox>

namespace Ui {
class patient_information;
}

class patient_information : public QDialog
{
    Q_OBJECT

public:
    explicit patient_information(QWidget *parent = nullptr);
    ~patient_information();

private slots:
    void on_pushButtonsave_clicked();

    void on_pushButtongoback_clicked();

private:
    Ui::patient_information *ui;
};

#endif // PATIENT_INFORMATION_H
