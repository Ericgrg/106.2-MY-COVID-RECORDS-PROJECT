#include "logout.h"
#include "ui_certificate.h"

#include "dashboard.h"    // including the header file dashboard in it

certificate::certificate(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::certificate)
{
    ui->setupUi(this);
}

certificate::~certificate()
{
    delete ui;
}

void certificate::on_backbutton_clicked()
{
    this->hide();          // will hide the certificate ui
    Dashboard dashBoard;   // calling the object of dashboard class
   dashBoard.setModal(true); // setting modal is true then
    dashBoard.exec();       // will show the dashboard ui
}

