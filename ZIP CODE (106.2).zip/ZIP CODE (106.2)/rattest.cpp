#include "rattest.h"
#include "ui_rattest.h"

#include "dashboard.h"    // including the header file dashboard in it
#include <QMessageBox>     // adding to show the message on ui.

rattest::rattest(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::rattest)
{
    ui->setupUi(this);
}

rattest::~rattest()
{
    delete ui;
}

void rattest::on_backbutton_clicked()
{
    this->hide();          // will hide the rat test ui
    Dashboard dashBoard;   // calling the object of dashboard class
   dashBoard.setModal(true); // setting modal is true then
    dashBoard.exec();       // will show the dashboard ui
}


void rattest::on_savebutton_clicked()
{
    //once all the field is input it will show saved message
QMessageBox::information(this, tr("Rat test input "), tr(" successfully saved "));
}

