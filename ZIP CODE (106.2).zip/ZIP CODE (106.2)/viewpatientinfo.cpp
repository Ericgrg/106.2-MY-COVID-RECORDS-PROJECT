#include "viewpatientinfo.h"
#include "ui_viewpatientinfo.h"

viewpatientinfo::viewpatientinfo(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::viewpatientinfo)
{
    ui->setupUi(this);
}

viewpatientinfo::~viewpatientinfo()
{
    delete ui;
}
