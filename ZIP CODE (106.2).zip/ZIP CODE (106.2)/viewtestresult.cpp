#include "viewtestresult.h"
#include "ui_testresult.h"


#include "dashboard.h"    // including the header file dashboard in it


testresult::testresult(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::testresult)
{
    ui->setupUi(this);
}

testresult::~testresult()
{
    delete ui;
}

void testresult::on_backbutton_clicked()
{
    this->hide();          // will hide the testresult ui
    Dashboard dashBoard;   // calling the object of dashboard class
   dashBoard.setModal(true); // setting modal is true then
    dashBoard.exec();       // will show the dashboard ui
}

