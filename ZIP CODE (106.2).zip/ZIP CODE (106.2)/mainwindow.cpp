#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

}

MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::on_pushButton_Login_clicked()
{
    this->hide();                  // will hide the mainwindow ui
    ul = new UserLogin(this);      //calling userlogin object  new instance and this is calling the parent construtor & will destroy.
    ul->show();                    // will show the userlogin ui by modelless approach
}


void MainWindow::on_pushButton_SignUp_clicked()
{
    this->hide();                // will hide the mainwindow ui
    us = new UserSignup(this); // calling usersingup object to create new instance
    us->show();                 // will show usersignup ui
}


void MainWindow::on_pushButtonadminlogin_clicked()
{

  this->hide();
al = new AdminLogin(this);
al->show();
}


void MainWindow::on_pushButtonadminregister_clicked()
{    this->hide();
     us = new UserSignup(this);
     us->show();

}



