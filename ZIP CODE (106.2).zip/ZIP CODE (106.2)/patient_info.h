#ifndef PATIENT_INFO_H
#define PATIENT_INFO_H

#include <QDialog>

namespace Ui {
class view_patient_info;
}

class view_patient_info : public QDialog
{
    Q_OBJECT

public:
    explicit view_patient_info(QWidget *parent = nullptr);
    ~view_patient_info();

private slots:
    void on_pushButoonsave_clicked();
    void on_backButton_clicked();

private:
    Ui::view_patient_info *ui;
};

#endif // PATIENT_INFO_H
