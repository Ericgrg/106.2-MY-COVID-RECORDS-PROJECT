#include "viewqr.h"
#include "ui_qrcode.h"



QRcode::QRcode(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::QRcode)
{
    ui->setupUi(this);
}

QRcode::~QRcode()
{
    delete ui;
}



