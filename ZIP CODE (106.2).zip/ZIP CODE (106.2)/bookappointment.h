#ifndef BOOKAPPOINTMENT_H
#define BOOKAPPOINTMENT_H

#include <QDialog>

namespace Ui {
class bookappointment;
}

class bookappointment : public QDialog
{
    Q_OBJECT

public:
    explicit bookappointment(QWidget *parent = nullptr);
    ~bookappointment();

private slots:
    void on_backbutton_clicked();



    void on_confirmbutton_clicked();

private:
    Ui::bookappointment *ui;
};

#endif // BOOKAPPOINTMENT_H
