#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSql>
#include <QSqlDatabase>
#include <QMessageBox>

#include "userlogin.h"      //adding the header file in it to the main window
#include "usersignup.h"     //adding the header file in it to the main window
#include "adminlogin.h"      //adding the header file in it to the main window




QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_pushButton_Login_clicked();

    void on_pushButton_SignUp_clicked();

    void on_pushButtonadminlogin_clicked();

    void on_pushButtonadminregister_clicked();





private:
    Ui::MainWindow *ui;
    // creating a pointer for userlogin , usersignup & adminlogin and an object of ul, us & al
    UserLogin *ul;
    UserSignup *us;
    AdminLogin *al;


};
#endif // MAINWINDOW_H
