#ifndef TEST_RESULT_INFO_H
#define TEST_RESULT_INFO_H



#include <QDialog>
#include <QtSql>
#include <QSqlDatabase>
#include <QMessageBox>


namespace Ui {
class test_result_info;
}

class test_result_info : public QDialog
{
    Q_OBJECT

public:
    explicit test_result_info(QWidget *parent = nullptr);
    ~test_result_info();

private slots:
    void on_save_clicked();

    void on_back_clicked();

private:
    Ui::test_result_info *ui;
};

#endif // TEST_RESULT_INFO_H
