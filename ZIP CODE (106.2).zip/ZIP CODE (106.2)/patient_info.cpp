#include "patient_info.h"
#include "ui_view_patient_info.h"


#include <QMessageBox>   // adding to diplay the message on ui

#include <QtSql>
#include <QSqlDatabase>

view_patient_info::view_patient_info(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::view_patient_info)
{
    ui->setupUi(this);
}

view_patient_info::~view_patient_info()
{
    delete ui;
}

void view_patient_info::on_pushButoonsave_clicked()
{


    //connecting to SQLITE database
    QSqlDatabase database = QSqlDatabase::addDatabase("QSQLITE");

   database.setDatabaseName("C:/Users/Nirmala/user_register.db");       // Path to my database

   if(database.open())
   {
       //Retrieve Data from Input Fields
       QString name = ui->name->text();
       QString date = ui->date->text();
       QString cellnumber = ui->cellnumber->text();
       QString address = ui->address->text();
       QString vaccinestatus = ui->vaccinestatus->text();

       //run our insert query

      QSqlQuery qry;
     qry.prepare("INSERT INTO patient_info (patientname, vaccinedate, cellnumber, address, vaccinestatus) values('"+name+"','"+date+"','"+cellnumber+"','"+address+"','"+vaccinestatus+"')");





    //want to execute and see
    if(qry.exec()){
       QMessageBox::information(this,"Inserted","Data inserted successfully");
   }
    else{
         QMessageBox::information(this,"Not Inserted","Data is not inserted");
   }

 }

}

