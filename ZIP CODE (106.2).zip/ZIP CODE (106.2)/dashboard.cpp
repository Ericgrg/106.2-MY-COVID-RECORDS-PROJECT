#include "dashboard.h"
#include "ui_dashboard.h"
#include "patient_information.h"
#include "test_result_info.h"




Dashboard::Dashboard(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dashboard)
{
    ui->setupUi(this);
}

Dashboard::~Dashboard()
{
    delete ui;
}






void Dashboard::on_pushButtonpatientinfo_clicked()
{
    this->hide();        // will hide the dashboard ui
    patient_information vp;       //creating an object of view_patient_info class
    vp.setModal(true);    // setting modal is true
    vp.exec();            // will open the new dailog view_patient_info ui
}


void Dashboard::on_pushButtontestresult_clicked()
{
    this->hide();        // will hide the dashboard ui
    test_result_info tp;       //creating an object of view_patient_info class
    tp.setModal(true);    // setting modal is true
    tp.exec();            // will open the new dailog view_patient_info ui
}

