#ifndef VIEWQR_H
#define VIEWQR_H

#include <QDialog>

namespace Ui {
class QRcode;
}

class QRcode : public QDialog
{
    Q_OBJECT

public:
    explicit QRcode(QWidget *parent = nullptr);
    ~QRcode();

private slots:


private:
    Ui::QRcode *ui;
};

#endif // VIEWQR_H
