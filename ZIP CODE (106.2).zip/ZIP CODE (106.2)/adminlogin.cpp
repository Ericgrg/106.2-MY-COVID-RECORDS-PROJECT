#include "adminlogin.h"
#include "ui_adminlogin.h"

#include "admindashboard.h"      // adding header file of admindashboard so that we can use the class  in it
#include <QMessageBox>   // adding to display the message on ui


AdminLogin::AdminLogin(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::AdminLogin)
{
    ui->setupUi(this);

}

AdminLogin::~AdminLogin()
{
    delete ui;
}


void AdminLogin::on_pushButton_clicked()
{

    // will display the message once the pushbutton is clicked.
    QMessageBox::information(this, tr("Admin Log in  "), tr("successfully log in"));

    this->hide();     // will hide the userlogin ui
    admindashboard db; // creating a object of dashboard class
   db.setModal(true); // setting modal is true
    db.exec();// will open the new dailog of dashboard ui
}

