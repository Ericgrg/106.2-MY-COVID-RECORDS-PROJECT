#ifndef LOGOUT_H
#define LOGOUT_H

#include <QDialog>

namespace Ui {
class certificate;
}

class certificate : public QDialog
{
    Q_OBJECT

public:
    explicit certificate(QWidget *parent = nullptr);
    ~certificate();

private slots:
    void on_backbutton_clicked();

private:
    Ui::certificate *ui;
};

#endif // LOGOUT_H
