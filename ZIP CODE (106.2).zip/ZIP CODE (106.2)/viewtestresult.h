#ifndef VIEWTESTRESULT_H
#define VIEWTESTRESULT_H

#include <QDialog>

namespace Ui {
class testresult;
}

class testresult : public QDialog
{
    Q_OBJECT

public:
    explicit testresult(QWidget *parent = nullptr);
    ~testresult();

private slots:
    void on_backbutton_clicked();

private:
    Ui::testresult *ui;
};

#endif // VIEWTESTRESULT_H
