#ifndef VIEWPATIENTINFO_H
#define VIEWPATIENTINFO_H

#include <QDialog>

namespace Ui {
class viewpatientinfo;
}

class viewpatientinfo : public QDialog
{
    Q_OBJECT

public:
    explicit viewpatientinfo(QWidget *parent = nullptr);
    ~viewpatientinfo();

private:
    Ui::viewpatientinfo *ui;
};

#endif // VIEWPATIENTINFO_H
